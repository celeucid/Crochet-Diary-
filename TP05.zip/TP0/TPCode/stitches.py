from cmu_graphics import *

def chainPress(app, mouseX, mouseY):
    if getChainIndex(app, mouseX, mouseY) != None: 
        app.selectedChainIndex = getChainIndex(app,mouseX, mouseY)
    else: 
        if app.selectedButtonIndex == 0 and (mouseX <= 90 and mouseX >= 30) and (mouseY <=160 and mouseY >= 100):
            newCenterPoint = (450, 260)
            app.chainCenters.append(newCenterPoint)   

def slipStitchPress(app,mouseX, mouseY):
    if getSlipStitchIndex(app, mouseX, mouseY) != None: 
        app.selectedSlipStitchIndex = getSlipStitchIndex(app,mouseX, mouseY)
    else: 
        if app.selectedButtonIndex == 4 and (mouseX <= 160 and mouseX >= 100) and (mouseY <=160 and mouseY >= 100):
            newCenterPoint = (450, 260)
            app.slipStitchCenters.append(newCenterPoint)  

def castOnPress(app, mouseX, mouseY):
    if getCastOnIndex(app, mouseX, mouseY) != None:
        app.selectedCastOnIndex =  getCastOnIndex(app, mouseX, mouseY)
    else:
        if app.selectedButtonIndex == 3 and (mouseX <= 90 and mouseX >= 30) and (mouseY <= 370 and mouseY >= 310):
            newCenterPoint = (450, 260)
            app.castOnCenters.append(newCenterPoint)


def getChainIndex(app, mouseX, mouseY):
    for i in range(len(app.chainCenters)-1, -1, -1):
        cx,cy = app.chainCenters[i]
        x0 = cx - 40
        x1 = cx + 40
        y0 = cy - 10
        y1 = cy + 10
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None    

def getSlipStitchIndex(app, mouseX, mouseY):
    for i in range(len(app.slipStitchCenters)-1, -1, -1):
        cx,cy = app.slipStitchCenters[i]
        x0 = cx - 5
        x1 = cx + 5
        y0 = cy - 5
        y1 = cy + 5
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   

def getCastOnIndex(app, mouseX, mouseY):
    for i in range(len(app.castOnCenters)-1, -1, -1):
        cx,cy = app.castOnCenters[i]
        x0 = cx - 36
        x1 = cx + 36
        y0 = cy - 36
        y1 = cy + 36
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   

def centerDicts(app):
    app.selectedChainIndex = -1
    app.chainCenters = [ ]

    app.selectedSlipStitchIndex = -1
    app.slipStitchCenters = [ ]

    # app.selectedSCIndex = -1
    # app.SCCenters = [ ]

    app.selectedCastOnIndex = -1
    app.castOnCenters = [ ]

def drawHDC(app):
    drawLine(130, 220, 130, 180)

def drawSC(app):
    drawLine(60, 215, 60, 190)
    drawLine(50, 202, 70, 202)

def drawSlipStich(app):
    for (cx, cy) in app.slipStitchCenters:
        drawCircle(cx, cy, 5)  

def drawChain(app):
    for (cx, cy) in app.chainCenters:
        drawOval(cx, cy, 30, 10,rotateAngle = 90, fill = None, 
                borderWidth = 2, border = 'black')   
       
def drawTC(app):
        drawLine(130, 250,130, 290)

def drawDC(app):
    drawLine(60, 250,60, 290)

def drawCastOn(app):
    iW, iH = getImageSize(app.castOn)
    for (cx, cy) in app.castOnCenters:
        drawImage(app.castOn, cx, cy, align = 'center', rotateAngle = -90,
                  width = iW//17, height = iH//17)   
    
def drawCastOff(app): 
    iW, iH = getImageSize(app.castOn)  
    drawImage(app.castOn, 130, 340, align = 'center', rotateAngle = 90,
              width = iW//16, height = iH//16)      

   