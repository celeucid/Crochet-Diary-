from cmu_graphics import *

def editScreenVariables(app):
    app.hook = [(165, 263), (285, 263), (405, 263), (525, 263), (645, 263), (765, 263)]
    app.hookColor = 'white'       
    app.selectedhookIndex = -1

    app.editScreen = False 
    app. isNewName = False 
    app.editBG = 'editScreen.png'
    app.designName = ''
    app.hookColor = 'white'
    app.hookSize = 0
    app.yarnSize = 0
    app.tension = 0 


def drawOptions(app):
    drawImage(app.editBG, 0, 0)

    drawhooks(app)
    color = 'white'
    borderSize = 1
    if app.isNewName == True:
        color = 'lightSalmon'
        borderSize = 5
    else: 
        color = 'white'
        borderSize = 1

    drawRect(450, 115, 370, 55, fill = color, border = 'darkRed')
    drawLabel(f'{app.designName}', 465, 140, align = 'left', size = 30, 
              borderWidth = borderSize, font = 'caveat', fill = 'darkRed')
    
    drawRect(930, 486, 150, 50, fill= 'white', border = 'black')

def drawhooks(app):
    for i in range(len(app.hook)):
        color = app.hookColor
        xrect, yrect = app.hook[i]
        if app.selectedhookIndex == i:
            color = 'lightSalmon'
        drawRect(xrect,yrect,110,60,fill=color,border='black')   

def gethookIndex(app, mouseX, mouseY):
    for i in range(len(app.hook)-1, -1, -1):
        xrect,yrect = app.hook[i]
        x0 = xrect - 10
        x1 = xrect + 110
        y0 = yrect - 10
        y1 = yrect + 110
        if ((x0 <= mouseX and mouseX <= x1)) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   


def main():
  runApp(width=1100, height=560)

# main()


