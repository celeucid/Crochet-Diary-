from cmu_graphics import *

def onAppStart(app):
    app.button1 = Button(770, 60, 150, 30)

def redrawAll(app):
    for i in range(4):
        pass
    




class Button:

    def __init__(self, xcoord, ycoord, l, w):
        self.x = xcoord
        self.y = ycoord 
        self.startX = 200
        self.startY = 200
    
    def makeButton(self):
        drawRect