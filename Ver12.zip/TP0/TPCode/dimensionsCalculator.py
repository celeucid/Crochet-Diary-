from cmu_graphics import *
# from stitches import *


def dimVariables(app):
    app.chainCoords = [ ]
    app.graphTable = None

    app.Designwidth = 0
    app.Designheight = 0

    app.highTopCoord = (0,0)
    app.intersectCoord = (0,0)
    app.lowBottomCoord = (0,0)

def makeTable(app):
    final = []
    for cols in range(16):
        row = getgraphRows(app)
        final.append(row)
    app.graphTable = final
       
def getgraphRows(app):
    rows = []
    for row in range(18):
        x = app.graphDots.pop(0)
        rows.append(x)
    return rows

def convertToCoords(app):
    makeTable(app)
    i = 0
    for (x,y) in app.chainCenters:
        if app.chainRotateList[i] == 0:
            app.chainCoords.append((x, y+15))
            app.chainCoords.append((x, y-15))
        elif app.chainRotateList[i] == 3:
            app.chainCoords.append((x+15, y))
            app.chainCoords.append((x-15, y))
        elif app.chainRotateList[i] == 2 or app.chainRotateList[i] == 4:
            app.chainCoords.append((x+15, y-15))
            app.chainCoords.append((x-15, y+15))
        elif app.chainRotateList[i] == 1 or app.chainRotateList[i] == 5:
            app.chainCoords.append((x+15, y+15))
            app.chainCoords.append((x-15, y-15))
        i += 1


def loopThroughGraph(app):
    lowestRow = 18
    lowestCol = 16
    highestRow = 0
    highestCol = 0

    convertToCoords(app)
    if len(app.chainCoords) == 0:
        return None
    app.chainCoords = set(app.chainCoords)
    rows, cols = len(app.graphTable), len(app.graphTable[0])

    for row in range(rows):
        for col in range(cols):
            curr = app.graphTable[row][col]

            if curr in app.chainCoords:
                if row <= lowestRow:
                    lowestRow = row
                elif row > highestRow:
                    highestRow = row
                if col <= lowestCol:
                    lowestCol = col
                elif col > highestCol:
                    highestCol = col 
   
    app.highTopCoord = app.graphTable[lowestRow][lowestCol]
    app.intersectCoord = app.graphTable[highestRow][lowestCol]
    app.lowBottomCoord = app.graphTable[highestRow][highestCol]
    return lowestRow, lowestCol, highestRow, highestCol,


def calculate(app):
    lowestRow, lowestCol, highestRow, highestCol = loopThroughGraph(app)
    print('theses are the thingies:', lowestRow, lowestCol, highestRow, highestCol)

    width = highestRow - lowestRow
    height = highestCol - lowestCol 

    app.Designwidth = width 
    app.Designheight = height

    print('width', app.Designwidth, 'height', app.Designheight)
    


def drawDimLines(app):

    (x1,y1) = app.highTopCoord
    (x2,y2) = app.intersectCoord
    (x3,y3) = app.lowBottomCoord 
    drawLine(x1-15,y1,x2-15,y2, lineWidth = 3, fill = 'red')
    drawLine(x2,y2+15,x3,y3+15, lineWidth = 3, fill = 'blue')

    # drawLabel()
    # drawLabel()
