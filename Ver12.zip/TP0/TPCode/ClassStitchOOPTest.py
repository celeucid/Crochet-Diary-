from cmu_graphics import *
from TpCode import *

class Stitch:

    def __init__(self, selectedIndex, w, l):
        self.selectedIndex = selectedIndex
        self.centers = [ ]
        self.rotateIndexList = [ ]
        self.w = w
        self.l = l

    def getStitchIndex(self,mouseX, mouseY):
        for i in range(len(app.centers[i])-1,-1,-1):
            cx, cy = app.chainCenters[i]
            x0 = cx - self.w
            x1 = cx + self.w
            y0 = cy - self.l
            y1 = cy + self.l
        if (x0 <= mouseX and mouseX <= x1) and (y0 <= mouseY and mouseY <= y1):
            return i
        return None     


    def press(self, mouseX, mouseY):
        if getStitchIndex(self, mouseX, mouseY) != None:
            self.selectedIndex = getStitchIndex(self,mouseX, mouseY)
        
        elif app.isRotate == True:
            if len(self.centers) == len(self.rotateIndexList):
                currStitch = (len(self.chain)-1)
                self.rotateIndexList[currStitch] = app.selectedRotIndex
            else:
                newRotation = app.selectedRotIndex
                self.rotateIndexList.append(newRotation)
        else:
            if app.selectedButtonIndex == 0:
                # diable all other showoptions
                app.isRotate = True
                #showoptions = true
                newCenterPoint = (450, 260)
                self.centers.append(newCenterPoint)
                self.rotateIndexList.append(0)


