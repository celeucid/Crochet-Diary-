from cmu_graphics import *
# from snapStitches import * 

def centerDicts(app):
    app.selectedChainIndex = -1
    app.chainCenters = [ ]
    app.chainRotateList = [ ]

    app.selectedSlipStitchIndex = -1
    app.slipStitchCenters = [ ]

    app.selectedSCIndex = -1
    app.SCCenters = [ ]

    app.selectedCastOnIndex = -1
    app.castOnCenters = [ ]

    app.selectedHDCIndex = -1
    app.HDCCenters = [ ]

    app.selectedTCIndex = -1
    app.TCCenters = [ ]

    app.selectedDCIndex = -1
    app.DCCenters = [ ]

def rotateFuncts(app):
    app.selectedRotIndex = 0
    app.rotateButtons = [(30, 380), (30, 416), (30, 454), (96, 380), (96, 416), (96, 454)]
    app.rotColor = 'white'

    app.isRotate = False

    app.showChainOptions = False
    app.chainRotation = 90

def checkCanvasStitches(app,mouseX, mouseY):
    if app.selectedChainIndex != None:
        app.selectedDCIndex = None
        app.selectedHDCIndex = None
        app.selectedSCIndex = None
        app.selectedSlipStitchIndex = None
        app.selectedCastOnIndex = None
        app.selectedButtonIndex = 0
        app.isRotate = False
        app.showChainOptions = False 

        if mouseX < 180: mouseX = 190
        elif mouseX > 750:mouseX = 740
        if mouseY < 20 : mouseY = 35
        elif mouseY > 550: mouseY = 535

        app.chainCenters[app.selectedChainIndex] = (mouseX, mouseY)
        # getClosestPoint(app) 
    
    elif app.selectedSlipStitchIndex != None:
        app.selectedDCIndex = None
        app.selectedTCIndex = None
        app.selectedHDCIndex = None
        app.selectedChainIndex = None
        app.selectedCastOnIndex = None
        app.selectedSCIndex = None
        app.selectedButtonIndex = 4

        if mouseX < 180: mouseX = 190
        elif mouseX > 750:mouseX = 740
        if mouseY < 20 : mouseY = 35
        elif mouseY > 550: mouseY = 535

        app.slipStitchCenters[app.selectedSlipStitchIndex] = (mouseX, mouseY) 
        # getClosestPoint(app) 
        
    elif app.selectedCastOnIndex != None:
        app.selectedDCIndex = None
        app.selectedTCIndex = None
        app.selectedHDCIndex = None
        app.selectedChainIndex = None
        app.selectedSlipStitchIndex = None
        app.selectedSCIndex = None
        app.selectedButtonIndex = 3

        if mouseX < 180: mouseX = 190
        elif mouseX > 750:mouseX = 740
        if mouseY < 20 : mouseY = 35
        elif mouseY > 550: mouseY = 535

        app.castOnCenters[app.selectedCastOnIndex] = (mouseX, mouseY)
        
    elif app.selectedSCIndex != None:
        app.selectedDCIndex = None
        app.selectedTCIndex = None
        app.selectedHDCIndex = None
        app.selectedChainIndex = None
        app.selectedSlipStitchIndex = None
        app.selectedCastOnIndex = None
        app.selectedButtonIndex = 1

        if mouseX < 180: mouseX = 190
        elif mouseX > 750:mouseX = 740
        if mouseY < 20 : mouseY = 35
        elif mouseY > 550: mouseY = 535

        app.SCCenters[app.selectedSCIndex] = (mouseX, mouseY)
        
    elif app.selectedHDCIndex != None:
        app.selectedDCIndex = None
        app.selectedTCIndex = None
        app.selectedSCIndex = None
        app.selectedChainIndex = None
        app.selectedSlipStitchIndex = None
        app.selectedCastOnIndex = None
        app.selectedButtonIndex = 5

        if mouseX < 180: mouseX = 180
        elif mouseX > 750:mouseX = 725
        if mouseY < 20 : mouseY = 35
        elif mouseY > 530: mouseY = 523
    
        app.HDCCenters[app.selectedHDCIndex] = (mouseX, mouseY)
        
    elif app.selectedTCIndex != None:
        app.selectedDCIndex = None
        app.selectedSCIndex = None
        app.selectedChainIndex = None
        app.selectedSlipStitchIndex = None
        app.selectedCastOnIndex = None
        app.selectedButtonIndex = 6

        if mouseX < 180: mouseX = 185
        elif mouseX > 750:mouseX = 730
        if mouseY < 20 : mouseY = 35
        elif mouseY > 550: mouseY = 535

        app.TCCenters[app.selectedTCIndex] = (mouseX, mouseY)
        
    elif app.selectedDCIndex != None:
        app.selectedTCIndex = None
        app.selectedSCIndex = None
        app.selectedHDCIndex = None
        app.selectedChainIndex = None
        app.selectedSlipStitchIndex = None
        app.selectedButtonIndex = 2

        if mouseX < 180: mouseX = 185
        elif mouseX > 750:mouseX = 730
        if mouseY < 20 : mouseY = 35
        elif mouseY > 550: mouseY = 535

        app.DCCenters[app.selectedDCIndex] = (mouseX, mouseY)

def checkRotation(app, rotation):
    if rotation == 0:
        rotation = 90
    elif rotation == 1:
        rotation = 45
    elif rotation == 2:
        rotation = -45
    elif rotation == 3:
        rotation = 0
    elif rotation == 4:
        rotation = 135
    elif rotation == 5:
        rotation = -135
    return rotation     

def drawRotateChainOptions(app):      
    drawOval(63,399,30,10, rotateAngle = 90, fill = None, border = 'black')
    drawOval(63,435,30,10, rotateAngle = 45, fill = None, border = 'black')
    drawOval(63,473,30,10, rotateAngle = -45, fill = None, border = 'black')
    
    drawOval(129,399,30,10, rotateAngle = 0, fill = None, border = 'black')
    drawOval(129,435,30,10, rotateAngle = 135, fill = None, border = 'black')
    drawOval(129,473,30,10, rotateAngle = -135, fill = None, border = 'black')

def chainPress(app, mouseX, mouseY):
    if getChainIndex(app, mouseX, mouseY) != None: 
        app.selectedChainIndex = getChainIndex(app,mouseX, mouseY)
    
    elif app.isRotate == True:
        if len(app.chainCenters) == len(app.chainRotateList):
            currChain = (len(app.chainCenters))-1
            app.chainRotateList[currChain] = app.selectedRotIndex  
        else:
            newRotation = app.selectedRotIndex
            app.chainRotateList.append(newRotation)
        
    else: 
        if app.selectedButtonIndex == 0:
            app.isRotate = True
            app.showChainOptions = True
            newCenterPoint = (450, 260)
            app.chainCenters.append(newCenterPoint)
            app.chainRotateList.append(0) 


def slipStitchPress(app,mouseX, mouseY):
    if getSlipStitchIndex(app, mouseX, mouseY) != None: 
        app.selectedSlipStitchIndex = getSlipStitchIndex(app,mouseX, mouseY)
    else: 
        if app.selectedButtonIndex == 4:
            newCenterPoint = (450, 260)
            app.slipStitchCenters.append(newCenterPoint)  

def castOnPress(app, mouseX, mouseY):
    if getCastOnIndex(app, mouseX, mouseY) != None:
        app.selectedCastOnIndex =  getCastOnIndex(app, mouseX, mouseY)
    else:
        if app.selectedButtonIndex == 3: 
        # and (mouseX <= 90 and mouseX >= 30) and (mouseY <= 370 and mouseY >= 310):
            newCenterPoint = (450, 260)
            app.castOnCenters.append(newCenterPoint)
            
def SCPress(app,mouseX, mouseY):
    if getSCIndex(app, mouseX, mouseY) != None: 
        app.selectedSCIndex = getSCIndex(app,mouseX, mouseY)
    else: 
        if app.selectedButtonIndex == 1:
        # and (mouseX <= 90 and mouseX >= 30) and (mouseY <=230 and mouseY >= 170):
            newCenterPoint = (450, 260)
            app.SCCenters.append(newCenterPoint)  

def HDCPress(app,mouseX, mouseY):
    if getHDCIndex(app, mouseX, mouseY) != None: 
        app.selectedHDCIndex = getHDCIndex(app,mouseX, mouseY)
    else: 
        if app.selectedButtonIndex == 5:
        # and (mouseX <= 160 and mouseX >= 100) and (mouseY <=230 and mouseY >= 170):
            newCenterPoint = (450, 260)
            app.HDCCenters.append(newCenterPoint) 

def TCPress(app,mouseX, mouseY):
    if getTCIndex(app, mouseX, mouseY) != None: 
        app.selectedTCIndex = getTCIndex(app,mouseX, mouseY)
    else: 
        if app.selectedButtonIndex == 6:
        # and (mouseX <= 160 and mouseX >= 100) and (mouseY <=300 and mouseY >= 240):
            newCenterPoint = (450, 260)
            app.TCCenters.append(newCenterPoint) 

def DCPress(app,mouseX, mouseY):
    if getDCIndex(app, mouseX, mouseY) != None: 
        app.selectedDCIndex = getDCIndex(app,mouseX, mouseY)
    else: 
        if app.selectedButtonIndex == 2:
            newCenterPoint = (450, 260)
            app.DCCenters.append(newCenterPoint) 

def getChainIndex(app, mouseX, mouseY):
    for i in range(len(app.chainCenters)-1, -1, -1):
        cx,cy = app.chainCenters[i]
        x0 = cx - 40
        x1 = cx + 40
        y0 = cy - 10
        y1 = cy + 10
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None    

def getSlipStitchIndex(app, mouseX, mouseY):
    for i in range(len(app.slipStitchCenters)-1, -1, -1):
        cx,cy = app.slipStitchCenters[i]
        x0 = cx - 5
        x1 = cx + 5
        y0 = cy - 5
        y1 = cy + 5
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   

def getCastOnIndex(app, mouseX, mouseY):
    for i in range(len(app.castOnCenters)-1, -1, -1):
        cx,cy = app.castOnCenters[i]
        x0 = cx - 36
        x1 = cx + 36
        y0 = cy - 36
        y1 = cy + 36
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None  

def getSCIndex(app,mouseX, mouseY):
    for i in range(len(app.SCCenters)-1, -1, -1):
        cx,cy = app.SCCenters[i]
        x0 = cx - 22
        x1 = cx + 22
        y0 = cy - 38
        y1 = cy + 38
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None  
 
def getHDCIndex(app,mouseX, mouseY):
    for i in range(len(app.HDCCenters)-1, -1, -1):
        cx,cy = app.HDCCenters[i]
        x0 = cx - 22
        x1 = cx + 22
        y0 = cy - 30
        y1 = cy + 30
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   

def getTCIndex(app,mouseX, mouseY):
    for i in range(len(app.TCCenters)-1, -1, -1):
        cx,cy = app.TCCenters[i]
        x0 = cx - 14
        x1 = cx + 14
        y0 = cy - 35
        y1 = cy + 35
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   

def getDCIndex(app,mouseX, mouseY):
    for i in range(len(app.DCCenters)-1, -1, -1):
        cx,cy = app.DCCenters[i]
        x0 = cx - 14
        x1 = cx + 14
        y0 = cy - 35
        y1 = cy + 35
        if (x0 <= mouseX and mouseX <= x1) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   

def drawRotateButtons(app):
    for i in range(len(app.rotateButtons)):
        color = app.rotColor
        xrect, yrect = app.rotateButtons[i]
        if app.selectedRotIndex == i:
            color = 'lightSalmon'
        drawRect(xrect,yrect,66,38, fill=color ,border='grey')  
    
def getRotIndex(app, mouseX, mouseY):
    for i in range(len(app.rotateButtons)-1, -1, -1):
        xrect,yrect = app.rotateButtons[i]
        x0 = xrect 
        x1 = xrect + 66
        y0 = yrect 
        y1 = yrect + 66
        if ((x0 <= mouseX and mouseX <= x1)) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None    

def drawChain(app):
    rotate = app.chainRotation
    i = 0
    for (cx, cy) in app.chainCenters:   
            r = app.chainRotateList[i]
            rotate = checkRotation(app, r)
            drawOval(cx, cy, 30, 10,rotateAngle = rotate, fill = None, 
                    borderWidth = 2, border = 'black')  
            i += 1

def drawHDC(app):
    wHDC, hHDC = getImageSize(app.hdc)
    for (cx, cy) in app.HDCCenters:
          drawImage(app.hdc, cx, cy, align = 'center', 
                    width = wHDC/1.5, height = hHDC/1.5)

def drawSC(app):
    wSC, hSC = getImageSize(app.sc)
    for (cx, cy) in app.SCCenters:
          drawImage(app.sc, cx, cy,align = 'center' , 
                    width = wSC/1.5, height = hSC/1.5)

def drawSlipStich(app):
    for (cx, cy) in app.slipStitchCenters:
        drawCircle(cx, cy, 5)  
       
def drawTC(app):
    wTC, hTC = getImageSize(app.tc)
    for (cx, cy) in app.TCCenters:
        drawImage(app.tc, cx, cy, 
                  width = wTC/1.5, height = hTC/1.5)

def drawDC(app):
    iWC, iHC = getImageSize(app.dc)
    for (cx, cy) in app.DCCenters:
        drawImage(app.dc, cx, cy, width = iWC/1.5, height = iHC/1.5)

def drawCastOn(app):
    iW, iH = getImageSize(app.castOn)
    for (cx, cy) in app.castOnCenters:
        drawImage(app.castOn, cx, cy, align = 'center', rotateAngle = -90,
                  width = iW//17, height = iH//17)   
    
def drawCastOff(app): 
    iW, iH = getImageSize(app.castOn)  
    drawImage(app.castOn, 130, 340, align = 'center', rotateAngle = 90,
              width = iW//16, height = iH//16)      

def trashStitches(app, mouseX, mouseY):
    if app.selectedChainIndex != None:
        if (mouseX >= 180 and mouseX <= 750) and (mouseY >= 515 and mouseY <= 550):
                app.chainCenters.pop(app.selectedChainIndex)
                app.chainRotateList.pop(app.selectedChainIndex)
                app.selectedChainIndex -= 1
        elif app.selectedSlipStitchIndex != None:
            if (mouseX >= 180 and mouseX <= 750) and (mouseY >= 515 and mouseY <= 550):
                app.slipStitchCenters.pop(app.selectedSlipStitchIndex)
                app.selectedSlipStitchIndex -= 1
        elif app.selectedSCIndex != None:
            if (mouseX >= 180 and mouseX <= 750) and (mouseY >= 515 and mouseY <= 550):
                app.SCCenters.pop(app.selectedSCIndex)
                app.selectedSCIndex -= 1
        elif app.selectedDCIndex != None:
            if (mouseX >= 180 and mouseX <= 750) and (mouseY >= 515 and mouseY <= 550):
                app.DCCenters.pop(app.selectedDCIndex)
                app.selectedDCIndex -= 1
        elif app.selectedCastOnIndex != None:
            if (mouseX >= 180 and mouseX <= 750) and (mouseY >= 515 and mouseY <= 550):
                app.castOnCenters.pop(app.selectedCastOnIndex)
                app.selectedCastOnIndex -= 1
        elif app.selectedHDCIndex != None:
            if (mouseX >= 180 and mouseX <= 750) and (mouseY >= 515 and mouseY <= 550):
                app.HDCCenters.pop(app.selectedHDCIndex)
                app.selectedHDCIndex -= 1
        elif app.selectedTCIndex != None:
            if (mouseX >= 180 and mouseX <= 750) and (mouseY >= 515 and mouseY <= 550):
                app.TCCenters.pop(app.selectedTCIndex)
                app.selectedTCIndex -= 1