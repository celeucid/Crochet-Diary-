from cmu_graphics import *

def getClosestPoint(app):
    for closestPointIndex in range(len(app.graphDots)):
        if app.selectedChainIndex != None:
            (dotX, dotY) = app.graphDots[closestPointIndex]
            (stitchX, stitchY) = app.chainCenters[app.selectedChainIndex]
            if (stitchY <= (dotY + 12) and stitchY >= (dotY - 12) and
                stitchX <= (dotX + 12) and stitchX >=(dotX - 12)):
                app.chainCenters[app.selectedChainIndex] = (dotX, (dotY+15))
        elif app.selectedSlipStitchIndex != None:
            (dotX, dotY) = app.graphDots[closestPointIndex]
            (stitchX, stitchY) = app.slipStitchCenters[app.selectedSlipStitchIndex]
            if (stitchY <= (dotY + 9) and stitchY >= (dotY - 9) and
                stitchX <= (dotX + 9) and stitchX >=(dotX - 9)):
                app.slipStitchCenters[app.selectedSlipStitchIndex] = (dotX, dotY)