from cmu_graphics import *

def onAppStart(app):
    app.button1 = Button(770, 60, 150, 30)

def redrawAll(app):
    for i in range(4):
        pass
    




class Button:

    def __init__(self, x, y):
        self.x = x
        self.y = y 
        self.len = 150
        self.wid = 200
    
    def makeButton(self):
        drawRect