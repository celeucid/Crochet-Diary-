from cmu_graphics import *
from stitches import *
from startScreen import *
from snapStitches import * 
from editScreen import *

def onAppStart(app):

    #start screen variables
    app.startScreen = False
    app.title = 'start.png'
    app.isHighlighting = False

    #editScreenVariables
    app.editScreen = False
    editScreenVariables(app)
    
    #main screen variables 
    app.drawingScreen = True
    app.button = ([(30, 100), (30, 170), (30, 240), (30, 310), (100, 100), 
                (100, 170), (100, 240), (100, 310)])
    app.buttonColor = 'white'         
    app.selectedButtonIndex = -1
    app.stitchName = 'stitch displayed here'
    app.castOn = 'castOn.png'
    app.dc = 'doubleCrochet.PNG'
    app.tc = 'tripleCrochet.PNG'
    app.sc = 'singleCrochet.PNG'
    app.hdc = 'halfdoubleCrochet.PNG'
    app.stitchNames = dict()
    centerDicts(app)
    #variables for graph and snapping function(snapStitches file)
    app.graphDots = [ ]

def redrawAll(app):

    if app.startScreen is True:
        drawTitle(app)
        startButton(app)
    
    if app.editScreen is True:
        for i in range(6):
            xrect=165+i*120
            drawRect(xrect,425,110,65,border='darkRed')
        drawOptions(app)    
        
    if app.drawingScreen is True:
        # drawRect(0,0, 1100, 560, fill = 'lightSalmon')

        #canvas border

        boardRow(app)
        drawButtons(app)
        drawStiches(app)
        drawTrash(app)
        drawRect(180, 20, 570, 530, fill = None, border = 'black', borderWidth = 3)

        #draw stitches for canvas
        drawChain(app)
        drawSlipStich(app)
        drawCastOn(app)
        drawSC(app)

        #draw curr stitch selected name 
        drawRect(30,60, 130, 30,fill='white',border='black')
        drawLabel(f'{app.stitchName}',94, 75, align = 'center')


def drawTrash(app):
    drawRect(180, 515, 570, 35, fill = 'lightSalmon', border = 'black')
    drawLabel('Trash',455, 530, align = 'center', size = 20)
        
def boardRow(app):
    for row in range(18):
        x = 210+row*30
        for col in range(16):
            y = 50+col*30
            app.graphDots.append((x,y))
            drawCircle(x, y, 2, fill = 'grey')

def drawButtons(app):
    for i in range(len(app.button)):
        color = app.buttonColor
        xrect, yrect = app.button[i]
        if app.selectedButtonIndex == i:
            color = 'grey'
        drawRect(xrect,yrect,60,60,fill=color,border='black')   

def getButtonIndex(app, mouseX, mouseY):
    for i in range(len(app.button)-1, -1, -1):
        xrect,yrect = app.button[i]
        x0 = xrect - 9
        x1 = xrect + 60
        y0 = yrect - 9
        y1 = yrect + 60
        if ((x0 <= mouseX and mouseX <= x1)) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None    

def getStitchName(app):
    app.stitchNames[0] = 'chain'
    app.stitchNames[1] = 'single crochet' 
    app.stitchNames[2] = 'double crochet'
    app.stitchNames[3] = 'cast on'
    app.stitchNames[4] = 'slip stitch'
    app.stitchNames[5] = 'half double crochet'        
    app.stitchNames[6] = 'triple crochet'
    app.stitchNames[7] = 'cast off'     
    
    if app.selectedButtonIndex in app.stitchNames:
        app.stitchName = app.stitchNames[app.selectedButtonIndex]

def onMousePress(app, mouseX, mouseY):
    #startScreen
    if app.startScreen == True:
        if ((mouseX >= 500 and mouseX <= 850)
            and (mouseY >= 280 and mouseY <=360)):
            app.editScreen = True
            app.startScreen = False 

    # editScreen Functions
    elif app.editScreen == True:
        if gethookIndex(app, mouseX, mouseY) != None: 
            app.selectedhookIndex = gethookIndex(app,mouseX, mouseY)
            assignhooksize(app)
        
        if getyarnIndex(app, mouseX, mouseY) != None: 
            app.selectedyarnIndex = getyarnIndex(app,mouseX, mouseY)
            assignyarnsize(app)

        if (mouseX <= 820 and mouseX >= 450) and (mouseY <=170 and mouseY >= 115):
            app.isNewName = True 
        elif app.isNewName == True:
            app.isNewName = False 
        if (mouseX <= 1080 and mouseX >= 930) and (mouseY <=536 and mouseY >= 486):
            app.drawingScreen = True
            app.editScreen = False 
 
    #drawingScreen press funtions 
    elif app.drawingScreen == True:    
        if getButtonIndex(app, mouseX, mouseY) != None: 
            app.selectedButtonIndex = getButtonIndex(app,mouseX, mouseY)

    chainPress(app, mouseX, mouseY)  
    slipStitchPress(app,mouseX, mouseY) 
    castOnPress(app, mouseX, mouseY)      
    SCPress(app,mouseX, mouseY)
    getStitchName(app)

def drawStiches(app): 
    iW, iH = getImageSize(app.castOn)
    iWC, iHC = getImageSize(app.dc)
    wHDC, hHDC = getImageSize(app.hdc)
    wSC, hSC = getImageSize(app.sc)
    wTC, hTC = getImageSize(app.tc)
    drawOval(60, 130, 30, 10,rotateAngle = 90, fill = None, 
             borderWidth = 2, border = 'black')
    drawCircle(130, 130, 5)  
    drawImage(app.tc, 95, 240, width = wTC/1.5, height = hTC/1.5)
    drawImage(app.sc, 60, 200,align = 'center' ,width = wSC/1.5, height = hSC/1.5)
    drawImage(app.hdc, 115, 195, align = 'center', width = wHDC/1.5, height = hHDC/1.5)
    drawImage(app.dc, 24, 240, width = iWC/1.5, height = iHC/1.5)
    drawImage(app.castOn, 60, 340, align = 'center', rotateAngle = -90,
              width = iW//14, height = iH//14)
    drawImage(app.castOn, 130, 340, align = 'center', rotateAngle = 90,
              width = iW//14, height = iH//14)  


def onMouseDrag(app, mouseX, mouseY):
    if app.drawingScreen == True:
        if app.selectedChainIndex != None:
            app.selectedSCIndex = None
            app.selectedSlipStitchIndex = None
            app.selectedCastOnIndex = None
            app.selectedButtonIndex = 0

            if mouseX < 180: mouseX = 190
            elif mouseX > 750:mouseX = 740
            if mouseY < 20 : mouseY = 35
            elif mouseY > 550: mouseY = 535

            app.chainCenters[app.selectedChainIndex] = (mouseX, mouseY)
            getClosestPoint(app) 
    
        elif app.selectedSlipStitchIndex != None:
            app.selectedChainIndex = None
            app.selectedCastOnIndex = None
            app.selectedSCIndex = None
            app.selectedButtonIndex = 4
            app.slipStitchCenters[app.selectedSlipStitchIndex] = (mouseX, mouseY) 
            getClosestPoint(app) 
        
        elif app.selectedCastOnIndex != None:
            app.selectedChainIndex = None
            app.selectedSlipStitchIndex = None
            app.selectedSCIndex = None
            app.selectedButtonIndex = 3
            app.castOnCenters[app.selectedCastOnIndex] = (mouseX, mouseY)
        
        elif app.selectedSCIndex != None:
            app.selectedChainIndex = None
            app.selectedSlipStitchIndex = None
            app.selectedCastOnIndex = None
            app.selectedButtonIndex = 3
            app.SCCenters[app.selectedSCIndex] = (mouseX, mouseY)

def onMouseRelease(app, mouseX, mouseY):
    if app.startScreen == True:
        pass      
    elif app.drawingScreen == True:
        if app.selectedChainIndex != None:
            if (mouseX >= 180 and mouseX <= 750) and (mouseY >= 515 and mouseY <= 550):
                app.chainCenters.pop(app.selectedChainIndex)
                app.selectedChainIndex -= 1
        app.selectedButtonIndex = -1    
        app.selectedSlipStitchIndex = None
        app.selectedChainIndex = None
        app.selectedCastOnIndex = None
        app.selectedSCIndex = None

def onMouseMove(app, mouseX, mouseY):
    if app.startScreen == True:
        if (mouseX >= 500 and mouseX <= 850) and (mouseY >= 280 and mouseY <=360):
            app.isHighlighting = True
        else:
            app.isHighlighting = False  
    if app.editScreen == True:
        if (mouseX >= 930 and mouseX <= 1080) and (mouseY >= 486 and mouseY <=536):
            app.isHighlighting = True
        else:
            app.isHighlighting = False  

def onKeyPress(app, key):
    if app.editScreen == True:
        if app.isNewName == True:
            if key == 'backspace' and app.designName != '':
                app.designName =  app.designName[:-1]
            if key == 'space':
                app.designName += ' '
            elif key.isalpha() and key is not 'backspace' and key is not 'enter' and key is not 'space':
                app.designName += key
            elif key == 'enter':
                app.isNewName = False 
    
def main():
  runApp(width=1100, height=560)

main()