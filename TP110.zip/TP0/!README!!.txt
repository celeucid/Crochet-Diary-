run tpCode.py for main code body. 

11/26:
finished rotation function 
