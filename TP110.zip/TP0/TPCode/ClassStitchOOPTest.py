from cmu_graphics import *

class Stitch:

    def __init__(self):
        pass