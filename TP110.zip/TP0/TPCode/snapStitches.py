from cmu_graphics import *

def getClosestPoint(app):
    for closestPointIndex in range(len(app.graphDots)):
        if app.selectedChainIndex != None:
            (dotX, dotY) = app.graphDots[closestPointIndex]
            (stitchX, stitchY) = app.chainCenters[app.selectedChainIndex]
            chainRotation = app.chainRotateList[app.selectedChainIndex]
            if (stitchY <= (dotY + 13) and stitchY >= (dotY - 13) and
                stitchX <= (dotX + 13) and stitchX >=(dotX - 13)):
                if chainRotation == 3:
                    app.chainCenters[app.selectedChainIndex] = (dotX+15, (dotY))
                elif chainRotation == 4 or chainRotation == 5 or chainRotation == 1 or chainRotation == 2:
                    app.chainCenters[app.selectedChainIndex] = (dotX+15, (dotY+15))
                else:
                    app.chainCenters[app.selectedChainIndex] = (dotX, (dotY+15))


        elif app.selectedSlipStitchIndex != None:
            (dotX, dotY) = app.graphDots[closestPointIndex]
            (stitchX, stitchY) = app.slipStitchCenters[app.selectedSlipStitchIndex]
            if (stitchY <= (dotY + 9) and stitchY >= (dotY - 9) and
                stitchX <= (dotX + 9) and stitchX >=(dotX - 9)):
                app.slipStitchCenters[app.selectedSlipStitchIndex] = (dotX, dotY)