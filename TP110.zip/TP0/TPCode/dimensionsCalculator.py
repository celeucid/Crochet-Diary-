from cmu_graphics import *


def dimVariables(app):
    app.chainCoords = [ ]

def convertToCoords(app):
    pass 

    
def loopthroughGraph(app):
    rows, cols = len(app.graphDots), len(app.graphDots[0])



    for row in range(rows):
        for col in range(cols):
            pass


