from cmu_graphics import *

def drawTitle(app):
    iW, iH = getImageSize(app.title) 
    drawRect(0,0,1100,560, fill = 'lightPink')
    drawImage(app.title, 550, 280, align = 'center', width = iW, height = iH)   

def startButton(app):
    if app.isHighlighting == True:
      color = 'orange'
      isBold = True
    else: 
      color = 'peachPuff' 
      isBold= False
    drawRect(500,280, 350, 80, fill = color, border = 'black')
    drawLabel('Create New Design', 682, 315, fill = 'darkRed', size = 25, bold = isBold, font = 'montserrat')
 

def main():
  runApp(width=1100, height=560)

# main()
