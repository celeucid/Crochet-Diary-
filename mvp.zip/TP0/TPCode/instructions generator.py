from cmu_graphics import *

#cast on cast off

def intsructionsFuncts(app):
    app.isCastOn = False
    app.isCastOff = False 
    pass