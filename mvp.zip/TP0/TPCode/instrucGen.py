from cmu_graphics import *
from dimCalc import*
import copy

#cast on cast off

def intsructionsFuncts(app):
    app.isCastOn = False
    app.isCastOff = False 
    pass
    app. instr = [ ]
    app.printinstr = False


def InstuctionGenerator(app):
    if app.isCastOn == False or app.isCastOff:
        return False 
    centerList = copy.copy(app.centers)
    return generated(app, centerList)

def generated(app, centerList):
    pass



def checkforCasts(app):
    
    graph = makeTable(app)
    rows, cols = len(graph), len(graph[0])
    
    for row in range(rows):
        for col in range(cols):
            if graph[row][col] == 0:
                return row, col    
def gen(app):

    drawLabel(f'{app.stitchList}', 780, 250, align = "left")
    
    # graph = makeTable(app)
    # rows, cols = len(graph), len(graph[0])

    # for row in range(rows):
    #     for col in range(cols):
    #         x = graph[row][col]
    #         if x in app.centers:


# def solveMiniSudoku(board):
#     Newboard = copy.deepcopy(board)
#     return solved(Newboard)
    
# def checkForZero(board):
#     rows, cols = len(board), len(board[0])
    
#     for row in range(rows):
#         for col in range(cols):
#             if board[row][col] == 0:
#                 return row, col
#     return None            

# def isComplete(board):
#     rows, cols = len(board), len(board[0])
    
#     for row in range(rows):
#         rowList = board[row]
#         if len(set(rowList)) != 4:
#             return False 
            
#     for col in range(cols):
#         colList = [board[row][col] for row in range(rows)]
#         if len(set(colList)) != 4:
#                 return False
#     quadOne = [board[0][0], board[0][1], board[1][0], board[1][1]]
#     quadTwo = [board[0][2], board[0][3], board[1][2], board[1][3]]
#     quadThree = [board[2][0], board[2][1], board[3][0], board[3][1]]
#     quadFour = [board[2][2], board[2][3], board[3][2], board[3][3]]
    
#     if (len(set(quadOne)) != 4 or len(set(quadTwo)) != 4 or 
#     len(set(quadThree)) != 4 or len(set(quadFour)) != 4):
#         return False

#     return True             

# def isLegal(board, row, col):
#     #check for no dupes except 0
#     rows, cols = len(board), len(board[0])
    
#     rowList = board[row]
#     colList = [board[row][col] for row in range(rows)]
#     quadOne = [board[0][0], board[0][1], board[1][0], board[1][1]]
#     quadTwo = [board[0][2], board[0][3], board[1][2], board[1][3]]
#     quadThree = [board[2][0], board[2][1], board[3][0], board[3][1]]
#     quadFour = [board[2][2], board[2][3], board[3][2], board[3][3]]
    
#     if (dupeHelper(rowList) != True or dupeHelper(colList) != True
#     or dupeHelper(quadOne) != True or dupeHelper(quadTwo) != True
#     or dupeHelper(quadThree) != True or dupeHelper(quadFour) != True):
#         return False
#     return True    
    
# def dupeHelper(L):
#     seen = set()
#     seenAgain = set()
#     for v in L:
#         if v in seen:
#             seenAgain.add(v)
#         seen.add(v) 
#     if len(seenAgain) == 0 or seenAgain == {0}:
#         return True
#     return False     
                    
# def solved(board):
#     rows, cols = len(board), len(board[0])
    
#     if checkForZero(board) == None and isComplete(board) == True:
#         return board
    
#     else:  
#         for move in range(1,5):
#             row, col = checkForZero(board)
#             print(board)
#             board[row][col] = move
#             if isLegal(board, row, col):
#                 sol = solved(board)
#                 if sol != None:
#                     return sol
#             board[row][col] = 0
#         return None    



