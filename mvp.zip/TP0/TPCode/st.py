from cmu_graphics import *
from snapstitch import *
from rotate import *
from colors import *

class button:
    def __init__(self, x, y, l, w):
        self.x = x
        self.y = y
        self.l = l
        self.w = w
        self.color = 'white'
        self.bord = 'cornflowerBlue'
    
    def draw(self):
        drawRect(self.x, self.y, self.l, self.w, fill=self.color, border = self.bord)


class stitch:
    def __init__(self, stitchtype):
        self.stitchtype = stitchtype

    def draw(self, app, mx, my, angle, color):
        r = checkRotation(app, angle)
        c = checkColor(app, color)
        if self.stitchtype == 'chain':
            drawOval(mx,my,30,10, fill = None,border = c, rotateAngle = r)   
        elif self.stitchtype == 'sc':
            # drawImage(app.sc, mx,my, rotateAngle = r)
            drawLabel('1', mx,my, font = 'StitchinCrochetW95', size = 40,
                       fill = c, rotateAngle = r, bold = True)
        elif self.stitchtype == 'ss':
            drawCircle(mx, my, 5, fill = c, rotateAngle = r)  
        elif self.stitchtype == 'hdc':
            # drawImage(app.hdc, mx,my, rotateAngle = r)
            drawLabel('2', mx,my, font = 'StitchinCrochetW95', size = 40, 
                      fill = c, rotateAngle = r, bold = True)
        elif self.stitchtype == 'dc':
           drawLabel('3', mx,my, font = 'StitchinCrochetW95', size = 40,
                     fill = c, rotateAngle = r, bold= True)
        elif self.stitchtype == 'tc':
            drawLabel('4', mx,my, font = 'StitchinCrochetW95', size = 40,
                      fill = c, rotateAngle = r, bold = True)
        elif self.stitchtype == 'castOn':
            drawLabel('l', mx,my, font = 'StitchinCrochetW95', size = 40,
                      fill = 'blue', rotateAngle = r, bold = True)
        elif self.stitchtype == 'castOff':
            drawLabel('l', mx,my, font = 'StitchinCrochetW95', size = 40,
                       fill = 'red', rotateAngle = r, bold = True)
    def count(self):
        pass

            
def drawrotateimg(app):
    if app.isRotate == True:
        drawRotateButtons(app)
    
    if app.showChainOptions == True:
        drawRotateChainOptions(app)
        
    if app.showDCOptions == True:
        drawRotateDCOptions(app)

    if app.TC == True:
        drawRotateTCOptions(app)
    
    if app.showHDCOptions == True:
        drawRotateHDCOptions(app)

    if app.showSCOptions == True:
        drawRotateSCOptions(app)

def determineStitchType(app, i):
    w = 0
    l = 0
    stitchtype = app.stitchList[i]
    if stitchtype == 'chain':
        w = 30
        l = 10
    elif stitchtype == 'sc':
        w = 30
        l = 30
    elif stitchtype == 'ss':
        w = 5
        l = 5
    elif stitchtype == 'hdc':
        w = 30
        l = 30
    elif stitchtype == 'dc':
        w = 30
        l = 30
    elif stitchtype == 'tc':
        w = 30
        l = 30
    elif stitchtype == 'castOn':
        w = 30
        l = 30
    elif stitchtype == 'castOff':
        w = 30
        l = 30
    return w, l

def drawStitches(app):
    iW, iH = getImageSize(app.castOn)
    drawOval(60, 130, 30, 10,rotateAngle = 90, fill = None, 
             borderWidth = 2, border = 'black')
    drawCircle(130, 130, 5)  
    drawImage(app.tc, 115, 255)
    drawImage(app.sc, 60, 200,align = 'center')
    drawImage(app.hdc, 130, 200, align = 'center')
    drawImage(app.dc, 45, 255)
    drawImage(app.castOn, 60, 340, align = 'center', rotateAngle = -90,
              width = iW//14, height = iH//14)
    drawImage(app.castOn, 130, 340, align = 'center', rotateAngle = 90,
              width = iW//14, height = iH//14)
    
def getStitchName(app):
    app.stitchNames[0] = 'chain'
    app.stitchNames[1] = 'single crochet' 
    app.stitchNames[2] = 'double crochet'
    app.stitchNames[3] = 'cast on'
    app.stitchNames[4] = 'slip stitch'
    app.stitchNames[5] = 'half double crochet'        
    app.stitchNames[6] = 'triple crochet'
    app.stitchNames[7] = 'cast off'     
    
    if app.selectedButtonIndex in app.stitchNames:
        app.stitchName = app.stitchNames[app.selectedButtonIndex]


def trashStitches(app, mouseX, mouseY):
    if app.selectedStitchIndex != -1:
        if (mouseX >= 180 and mouseX <= 750) and (mouseY >= 515 and mouseY <= 550):
                    app.centers.pop(app.selectedStitchIndex)
                    app.rotation.pop(app.selectedStitchIndex)
                    app.stitchList.pop(app.selectedStitchIndex)
                    app.selectedStitchIndex -= 1
                    if app.isCastOn == True:
                        app.isCastOn = False
                    elif app.isCastOff == True:
                        app.isCastOff = False 
                    else:
                        app.isCastOn = False
                        app.isCastOff = False 

def drawRotateChainOptions(app):      
    drawOval(63,399,30,10, rotateAngle = 90, fill = None, border = 'black')
    drawOval(63,435,30,10, rotateAngle = 45, fill = None, border = 'black')
    drawOval(63,473,30,10, rotateAngle = -45, fill = None, border = 'black')
    
    drawOval(129,399,30,10, rotateAngle = 0, fill = None, border = 'black')
    drawOval(129,435,30,10, rotateAngle = 135, fill = None, border = 'black')
    drawOval(129,473,30,10, rotateAngle = -135, fill = None, border = 'black')

def drawRotateDCOptions(app):
    drawImage(app.dc,50, 383, rotateAngle = 90)
    drawImage(app.dc,45 , 420, rotateAngle = 45)
    drawImage(app.dc,45, 460, rotateAngle = -45)

    drawImage(app.dc,115 , 383, rotateAngle = 0)
    drawImage(app.dc,110, 420, rotateAngle = 135)
    drawImage(app.dc,110 , 460, rotateAngle = -135)

def drawRotateTCOptions(app):
    drawImage(app.tc,50, 383, rotateAngle = 90)
    drawImage(app.tc,45 , 420, rotateAngle = 45)
    drawImage(app.tc,45, 460, rotateAngle = -45)

    drawImage(app.tc,115 , 383, rotateAngle = 0)
    drawImage(app.tc,110, 420, rotateAngle = 135)
    drawImage(app.tc,110 , 460, rotateAngle = -135)

def drawRotateHDCOptions(app):
    drawImage(app.hdc,50, 383, rotateAngle = 90)
    drawImage(app.hdc,45 , 420, rotateAngle = 45)
    drawImage(app.hdc,45, 460, rotateAngle = -45)

    drawImage(app.hdc,115 , 383, rotateAngle = 0)
    drawImage(app.hdc,110, 420, rotateAngle = 135)
    drawImage(app.hdc,110 , 460, rotateAngle = -135)

def drawRotateSCOptions(app):
    drawImage(app.sc,50, 383, rotateAngle = 90)
    drawImage(app.sc,45 , 420, rotateAngle = 45)
    drawImage(app.sc,45, 460, rotateAngle = -45)

    drawImage(app.sc,115 , 383, rotateAngle = 0)
    drawImage(app.sc,110, 420, rotateAngle = 135)
    drawImage(app.sc,110 , 460, rotateAngle = -135)


def pressFuncts(app):
        if app.selectedButtonIndex == 0:
            app.stitchList.append('chain')
            app.centers.append((240,80))
            app.rotation.append(0)
            app.color.append(5)
            app.isRotate = True
            app.showChainOptions = True

        elif app.selectedButtonIndex == 1:
            app.stitchList.append('sc')
            app.centers.append((210,50))
            app.rotation.append(0)
            app.color.append(5)
            app.isRotate = True
            app.showSCOptions = True

        elif app.selectedButtonIndex == 2:
            app.stitchList.append('dc')
            app.centers.append((210, 50))
            app.rotation.append(0)
            app.color.append(5)
            app.isRotate = True
            app.showDCOptions = True

        elif app.selectedButtonIndex == 3:
            if app.isCastOn == False:
                app.stitchList.append('castOn')
                app.centers.append((210,50))
                app.rotation.append(0)
                app.color.append(5)
                app.isRotate = True
                app.isCastOn = True 


        elif app.selectedButtonIndex ==4:
            app.stitchList.append('ss')
            app.centers.append((210,50))
            app.rotation.append(0)
            app.color.append(5)


        elif app.selectedButtonIndex == 5:
            app.stitchList.append('hdc')
            app.centers.append((210,50))
            app.rotation.append(0)
            app.color.append(5)
            app.isRotate = True
            app.showHDCOptions = True

        elif app.selectedButtonIndex == 6:
            app.stitchList.append('tc')
            app.centers.append((210,50))
            app.rotation.append(0)
            app.color.append(5)
            app.isRotate = True
            app.TC = True

    

        elif app.selectedButtonIndex == 7:
            if app.isCastOff == False:
                app.stitchList.append('castOff')
                app.centers.append((210,50))
                app.rotation.append(0)
                app.color.append(5)
                app.isRotate = True
                app.isCastOff = True

def drawCastSelection(app):
    if app.isCastOn == True:
        drawRect(30, 310, 60, 60, fill = 'lightSalmon')
    if app.isCastOff == True:
        drawRect(100, 310, 60, 60 ,fill = 'lightSalmon')