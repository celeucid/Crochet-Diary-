from cmu_graphics import *

def drawRotateButtons(app):
    for i in range(len(app.rotateButtons)):
        color = app.rotColor
        xrect, yrect = app.rotateButtons[i]
        if app.selectedRotIndex == i:
            color = 'lightSalmon'
        drawRect(xrect,yrect,66,38, fill=color ,border='grey')  

def getRotIndex(app, mouseX, mouseY):
    for i in range(len(app.rotateButtons)-1, -1, -1):
        xrect,yrect = app.rotateButtons[i]
        x0 = xrect 
        x1 = xrect + 66
        y0 = yrect 
        y1 = yrect + 66
        if ((x0 <= mouseX and mouseX <= x1)) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None   


def checkRotation(app, rotation):
    if rotation == 0:
        rotation = 90
    elif rotation == 1:
        rotation = 45
    elif rotation == 2:
        rotation = -45
    elif rotation == 3:
        rotation = 0
    elif rotation == 4:
        rotation = 135
    elif rotation == 5:
        rotation = -135
    return rotation   


