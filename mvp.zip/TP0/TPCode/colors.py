from cmu_graphics import *

def colorFuncts(app):
    app.colorbutton = [(790, 400), (790, 440), (790, 480),(840, 400), (840, 440), (840, 480)]
    app.border = 'black'
    app.selectedColorIndex = -1

def drawColorButts(app):
    color = 'white'
    bord = app.border
    for i in range(len(app.colorbutton)):
        xrect, yrect = app.colorbutton[i]
        if app.selectedColorIndex == i:
            bord = 'blue'
        else:
            bord = app.border
        if i == 0:
            color = 'lightCoral'
        elif i == 1:
            color = 'plum'
        elif i == 2:
            color = 'moccasin'
        elif i == 3:
            color = 'mediumSeaGreen'
        elif i == 4:
            color = 'powderBlue'
        elif i == 5:
            color = 'black'

        drawRect(xrect,yrect,30,30,fill=color,border=bord, borderWidth = 3)  

def checkColor(app, color):
    if color== 0:
        color= 'lightCoral'
    elif color== 1:
        color= 'plum'
    elif color== 2:
        color= 'moccasin'
    elif color== 3:
        color= 'mediumSeaGreen'
    elif color== 4:
        color= 'powderBlue'
    elif color== 5:
        color= 'black'
    return color  


def getColorIndex(app, mouseX, mouseY):
    for i in range(len(app.colorbutton)-1, -1, -1):
        xrect,yrect = app.colorbutton[i]
        x0 = xrect 
        x1 = xrect + 30
        y0 = yrect 
        y1 = yrect + 30
        if ((x0 <= mouseX and mouseX <= x1)) and (y0 <=mouseY and mouseY <=y1):
            return i
    return None    
