from cmu_graphics import *

class Dot:
    def __init__(self, x, y, r=20):
        self.x = x
        self.y = y
        self.r = r
        self.color = 'lightBlue'

    def draw(self):
        drawCircle(self.x,self.y,self.r, fill= self.color)
    
def onAppStart(app):
        app.circles = []
    
def onMousePress(app,mouseX, mouseY):
        c = Dot(mouseX, mouseY)
        app.circles.append(c)
    
def redrawAll(app):
        for c in app.circles:
            c.draw()
def onMouseDrag(app, mouseX, mouseY):
     print('hi')

def main():
  runApp()

main()
    
        
    
