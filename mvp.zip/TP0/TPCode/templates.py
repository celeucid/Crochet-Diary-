from cmu_graphics import *

def templates(app, key):
    if key == 'b':
        print(len(app.centers))
        print(len(app.stitchList))
        print(len(app.rotation))
        print(len(app.color))
        app.centers = [(479, 275), (465, 260), (465, 290), (450, 275), (480, 245), (450, 245),
        (435, 245), (495, 249), (450, 305), (480, 305), (430, 305), (495, 307),
        (420, 305), (420, 275), (420, 245), (435, 230), (495, 230), (465, 229),
        (510, 275), (509, 245), (510, 305), (435, 320), (465, 321), (495, 320), 
        (495, 290), (435, 290), (405, 215), (525, 214), (405, 335), (525, 335), 
        (405, 230), (525, 227), (405, 320), (510, 335), (390, 335), (390, 305), 
        (390, 275), (390, 245), (405, 198), (465, 200), (495, 200), (435, 200), 
        (390, 215), (525, 200), (540, 215), (540, 275), (540, 245), (540, 305), 
        (540, 335), (525, 348), (495, 349), (465, 347), (435, 350), (405, 347)]
        app. stitchList =['chain', 'chain', 'chain', 'chain', 'dc', 'tc', 'tc', 'dc', 'tc', 'dc', 
        'dc', 'tc', 'chain', 'chain', 'chain', 'chain', 'chain', 'chain', 'chain', 
        'chain', 'chain', 'chain', 'chain', 'chain', 'tc', 'tc', 'sc', 'sc', 'sc', 
        'sc', 'sc', 'sc', 'sc', 'sc', 'chain', 'chain', 'chain', 'chain', 'chain', 
        'chain', 'chain', 'chain', 'chain', 'chain', 'chain', 'chain', 'chain', 
        'chain', 'chain', 'chain', 'chain', 'chain', 'chain', 'chain'] 
        app.rotation=[0, 3, 3, 0, 3, 3, 2, 1, 3, 3, 5, 4, 0, 0, 0, 3, 3, 3, 0, 0, 0, 
        3, 3, 3, 0, 0, 4, 5, 5, 4, 0, 0, 0, 3, 0, 0, 0, 0, 3, 3, 3, 3, 0, 
        3, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3]
        app.color =[5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 
        5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,5, 5, 5, 5, 5, 5, 5,
        5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5]
        print(len(app.centers))
        print(len(app.stitchList))
        print(len(app.rotation))
        print(len(app.color))
