from cmu_graphics import *

def dimVariables(app):
    app.Coords = [ ]
    app.graphTable = None


    app.Designwidth = 0
    app.Designheight = 0

    app.highTopCoord = (0,0)
    app.intersectCoord = (0,0)
    app.lowBottomCoord = (0,0)

    app.actalwidth = 0
    app.actualheight = 0

    app.notValid = False 

def makeTable(app):
    final = []
    for cols in range(16):
        row = getgraphRows(app)
        final.append(row)
    app.graphTable = final
       

       
def getgraphRows(app):
    rows = []
    for row in range(18):
        x = app.graphDots.pop(0)
        rows.append(x)
    return rows

def convertToCoords(app):
    makeTable(app)
    i = 0
    for (x,y) in app.centers:
        if app.stitchList[i] == 'chain':
            if app.rotation[i] == 0:
                app.Coords.append((x, y+15))
                app.Coords.append((x, y-15))
            elif app.rotation[i] == 3:
                app.Coords.append((x+15, y))
                app.Coords.append((x-15, y))
            elif app.rotation[i] == 2 or app.rotation[i] == 4:
                app.Coords.append((x+15, y-15))
                app.Coords.append((x-15, y+15))
            elif app.rotation[i] == 1 or app.rotation[i] == 5:
                app.Coords.append((x+15, y+15))
                app.Coords.append((x-15, y-15))
        elif app.stitchList[i] == 'ss':
              app.Coords.append((x, y))
        else:
            if app.rotation[i] == 0:
                app.Coords.append((x, y+15))
                app.Coords.append((x, y-15))
            elif app.rotation[i] == 3:
                app.Coords.append((x+15, y))
                app.Coords.append((x-15, y))
            elif app.rotation[i] == 2 or app.rotation[i] == 4:
                app.Coords.append((x+15, y-15))
                app.Coords.append((x-15, y+15))
            elif app.rotation[i] == 1 or app.rotation[i] == 5:
                app.Coords.append((x+15, y+15))
                app.Coords.append((x-15, y-15))

        i += 1
    

def loopThroughGraph(app):
    lowestRow = 18
    lowestCol = 16
    highestRow = 0
    highestCol = 0
    if len(app.centers) <= 4:
        return None
    convertToCoords(app)
    graph = app.graphTable 
    app.Coords = set(app.Coords)
    rows, cols = len(graph), len(graph[0])

    for row in range(rows):
        for col in range(cols):
            curr = graph[row][col]

            if curr in app.Coords:
                if row <= lowestRow:
                    lowestRow = row
                elif row > highestRow:
                    highestRow = row
                if col <= lowestCol:
                    lowestCol = col
                elif col > highestCol:
                    highestCol = col 

    app.highTopCoord = graph[lowestRow][lowestCol]
    app.intersectCoord = graph[highestRow][lowestCol]
    app.lowBottomCoord = graph[highestRow][highestCol]
    return lowestRow, lowestCol, highestRow, highestCol

def calculate(app):
    app.Designwidth = 0
    app.Designheight = 0
    app.actalwidth = 0
    app.actualheight = 0

    lowestRow, lowestCol, highestRow, highestCol = loopThroughGraph(app)
    print('theses are the thingies:', lowestRow, lowestCol, highestRow, highestCol)
    
    width = highestRow - lowestRow
    height = highestCol - lowestCol 

    app.Designwidth = width 
    app.Designheight = height

    app.actualwidth = (app.hookSize*app.yarnSize) * app.Designwidth
    app.actualheight = (app.hookSize*app.yarnSize) * app.Designheight
    print(app.hookSize, app.yarnSize, app.Designheight)

    print('width', app.Designwidth, 'height', app.Designheight)

def drawDimLines(app):

    (x1,y1) = app.highTopCoord
    (x2,y2) = app.intersectCoord
    (x3,y3) = app.lowBottomCoord 
    drawLine(x1-20,y1,x2-20,y2, lineWidth = 3, fill = 'red')
    drawLine(x2,y2+20,x3,y3+20, lineWidth = 3, fill = 'blue')

    drawLabel(f'your design is {app.Designheight} rows low, which is: {app.actualheight}cm', 780, 290, align = 'left')
    drawLabel(f'your design is {app.Designwidth} cols high, which is: {app.actualwidth}cm ', 780, 270, align = 'left')
              

    drawLabel(f'your final design would be:{app.actualwidth}cmx{app.actualheight}cm', 780, 310, align = 'left')
    # drawLabel()

def drawNotValid(app):
    drawLabel(' warning:not enough stitches to calculate', 800, 300, fill = 'red', align = 'left')

