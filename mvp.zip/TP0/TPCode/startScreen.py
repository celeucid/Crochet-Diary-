from cmu_graphics import *

def drawTitle(app):
    iW, iH = getImageSize(app.title) 
    drawRect(0,0,1100,560, fill = 'lightPink')
    drawImage(app.title, 550, 280, align = 'center', width = iW, height = iH)   

def startButton(app):
    if app.isHighlighting == True:
      color = 'cornflowerBlue'
      isBold = True
    else: 
      color = 'lightCyan' 
      isBold= False
    drawRect(500,320, 350, 80, fill = color, border = 'black')
    drawLabel('Create New Design', 682, 355, fill = 'black', size = 25, bold = isBold, font = 'montserrat')
 
def drawNameWarning(app):
    drawLabel('over word limit', 635, 180, fill= 'red')
   
def main():
  runApp(width=1100, height=560)

# main()
