run main.py for main code body. 

please download tiff file linked in code to run.

to sample app functions, press 'b' to summon template of basic granny square crochet. 


